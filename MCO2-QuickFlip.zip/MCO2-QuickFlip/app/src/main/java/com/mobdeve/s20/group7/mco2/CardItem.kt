package com.mobdeve.s20.group7.mco2

class CardItem(private val question: String, private val answer: String) {

    fun getQuestion(): String {
        return question
    }

    fun getAnswer(): String {
        return answer
    }
}
